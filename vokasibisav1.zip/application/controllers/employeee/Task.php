<?php  
	/**
	 * 
	 */
	class Task extends My_Controller
	{
		public function index(){
			echo "hello";
		}
	}
?>