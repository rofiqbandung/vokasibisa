<?php
	/**
	 * 
	 */
	class My_Controller extends CI_Controller
	{
		
	}
?>