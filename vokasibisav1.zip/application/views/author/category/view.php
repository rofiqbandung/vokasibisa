	<div id="con_main">
		</table>
		<form action="" method="post">
		<table width="" border="1"  class="view_table">
		  <tr class="tr_stl" >
			<tr>
				<td width="150"><strong>Word</strong></td>
				<td width=""><strong><?=$word_info['word']?></strong></td>
			</tr>
			<tr>
				<td>Pronunciation</td>
				<td width="" style="font-size:17px; letter-spacing:1px"><?=$word_info['pronunciation']?></td>
			</tr>
			<tr>
				<td>Parts of Speech</td>
				<td width=""><?=$word_info['partsofspeech']?></td>
			</tr>

			<tr>
				<td>Base Meaning</td>
				<td width="" style="font-size:17px; letter-spacing:1px"><?=$word_info['base_meaning']?></td>
			</tr>

			<tr>
				<td>Meaning</td>
				<td width="" style="font-size:17px; letter-spacing:1px"><?=$word_info['meaning']?></td>
			</tr>
			<tr>
				<td>Synonyms</td>
				<td width="" ><?=$word_info['synonyms']?></td>
			</tr>
			<tr>
				<td>Antonyms</td>
				<td width=""><?=$word_info['antonyms']?></td>
			</tr>
			<tr>
				<td>Example</td>
				<td width=""><?=$word_info['example']?></td>
			</tr>

			<tr>
				<td>Hits</td>
				<td width=""><?=$word_info['hit']?></td>
			</tr>
		  
		</table>
		</form>
		
	</div>